local helpers = gFunc.LoadFile('..\\lib\\helpers.lua');

local modifiers = {}

modifiers.STR = {
    'Slice',
    'Dark Harvest',
    'Shadow of Death',
    'Nightmare Scythe',
    'Spinning Scythe',
    'Vorpal Scythe',
    'Cross Reaper',
    'Spiral Hell',
    'Catastrophe',
    'Quietus',
    'Insurgency',
    'Combo',
    'Backhand Blow',
    'Raging Fists',
    'Spinning Attack',
    'Dragon Kick',
    'Asuran Fists',
    'Tornado Kick',
    'Victory Smite',
    'Stringing Pummel',
    'Pyrrhic Kleos',
    'Fast Blade',
    'Burning Blade',
    'Red Lotus Blade',
    'Flat Blade',
    'Shining Blade',
    'Seraph Blade',
    'Circle Blade',
    'Vorpal Blade',
    'Swift Blade',
    'Savage Blade',
    'Knights of Round',
    'Expiacion',
    'Uriel Blade',
    'Hard Slash',
    'Power Slash',
    'Frostbite',
    'Freezebite',
    'Shockwave',
    'Crescent Moon',
    'Sickle Moon',
    'Spinning Slash',
    'Ground Strike',
    'Resolution',
    'Raging Axe',
    'Smash Axe',
    'Gale Axe',
    'Avalanche Axe',
    'Spinning Axe',
    'Rampage',
    'Calamity',
    'Mistral Axe',
    'Decimation',
    'Ruinator',
    'Cloudsplitter',
    'Shield Break',
    'Iron Tempest',
    'Sturmwind',
    'Armor Break',
    'Keen Edge',
    'Weapon Break',
    'Raging Rush',
    'Full Break',
    'Steel Cyclone',
    'Fell Cleave',
    'Metatron Torment',
    'Ukko\'s Fury',
    'King\'s Justice',
    'Double Thrust',
    'Thunder Thrust',
    'Raiden Thrust',
    'Leg Sweep',
    'Penta Thrust',
    'Vorpal Thrust',
    'Skewer',
    'Wheeling Thrust',
    'Impulse Drive',
    'Sonic Thrust',
    'Stardiver',
    'Camlann\'s Torment',
    'Drakesbane',
    'Blade: Rin',
    'Blade: Teki',
    'Blade: To',
    'Blade: Chi',
    'Blade: Ei',
    'Blade: Jin',
    'Blade: Ten',
    'Blade: Ku',
    'Blade: Kamu',
    'Tachi: Enpi',
    'Tachi: Hobaku',
    'Tachi: Goten',
    'Tachi: Kagero',
    'Tachi: Jinpu',
    'Tachi: Koki',
    'Tachi: Yukikaze',
    'Tachi: Gekko',
    'Tachi: Kasha',
    'Tachi: Shoha',
    'Tachi: Kaiten',
    'Tachi: Fudo',
    'Tachi: Rana',
    'Heavy Swing',
    'Rock Crusher',
    'Earth Crusher',
    'Starburst',
    'Sunburst',
    'Shell Crusher',
    'Full Swing',
    'Cataclysm',
    'Shining Strike',
    'Seraph Strike',
    'Brainshaker',
    'Skullbreaker',
    'True Strike',
    'Judgment',
    'Hexa Strike',
    'Flash Nova',
    'Randgrith',
    'Refulgent Arrow',
    'Namas Arrow',

}

modifiers.VIT = {
    'Shoulder Tackle',
    'One Inch Punch',
    'Howling Fist',
    'Final Heaven',
    'Herculean Slash',
    'Torcleaver',
    'Upheaval',

}

modifiers.DEX = {
    'Shijin Spiral',
    'Wasp Sting',
    'Gust Slash',
    'Viper Bite',
    'Cyclone',
    'Dancing Edge',
    'Shark Bite',
    'Evisceration',
    'Aeolian Edge',
    'Rudra\'s Storm',
    'Mandalic Stab',
    'Chant du Cygne',
    'Dimidiation',
    'Bora Axe',
    'Onslaught',
    'Geirskogul',
    'Blade: Retsu',
    'Blade: Yu',
    'Blade: Shun',
    'Blade: Metsu',
    'Jishnu\'s Radiance',

}

modifiers.AGI = {
    'Exenterator',
    'Blade: Hi',
    'Flaming Arrow',
    'Piercing Arrow',
    'Dulling Arrow',
    'Sidewinder',
    'Blast Arrow',
    'Arching Arrow',
    'Empyreal Arrow',
    'Apex Arrow',
    'Hot Shot',
    'Split Shot',
    'Sniper Shot',
    'Slug Shot',
    'Blast Shot',
    'Heavy Shot',
    'Detonator',
    'Numbing Shot',
    'Last Stand',
    'Coronach',
    'Wildfire',
    'Trueflight',
    'Leaden Salute',

}

modifiers.INT = {
    'Spirit Taker',
    'Shattersoul',
    'Gate of Tartarus',
    'Vidohunir',
    'Exudation',

}

modifiers.MND = {
    'Guillotine',
    'Energy Steal',
    'Energy Drain',
    'Sanguine Blade',
    'Requiescat',
    'Death Blossom',
    'Retribution',
    'Omnicience',
    'Garland of Bliss',
    'Black Halo',
    'Realmrazer',
    'Mystic Boon',

}

modifiers.CHR = {
    'Shadowstitch',
    'Mordant Rime',
    'Primal Rend',
    'Tachi: Ageha',

}

modifiers.Soil = {
    'Aeolian Edge',
    'Asuran Fists',
    'Avalanche Axe',
    'Blade: Ku',
    'Blade: Retsu',
    'Blade: Ten',
    'Calamity',
    'Catastrophe',
    'Crescent Moon',
    'Dancing Edge',
    'Entropy',
    'Evisceration',
    'Exenterator',
    'Expiacion',
    'Fast Blade',
    'Hard Slash',
    'Impulse Drive',
    'Iron Tempest',
    'King\'s Justice',
    'Leaden Salute',
    'Mercy Stroke',
    'Nightmare Scythe',
    'Omniscience',
    'Primal Rend',
    'Pyrrhic Kleos',
    'Rampage',
    'Requiescat',
    'Resolution',
    'Retribution',
    'Savage Blade',
    'Seraph Blade',
    'Shattersoul',
    'Shining Blade',
    'Sickle Moon',
    'Slice',
    'Spinning Axe',
    'Spinning Scythe',
    'Spiral Hell',
    'Stardiver',
    'Stringing Pummel',
    'Sturmwind',
    'Swift Blade',
    'Tachi: Enpi',
    'Tachi: Jinpu',
    'Tachi: Rana',
    'Trueflight',
    'Viper Bite',
    'Vorpal Blade',
    'Vorpal Scythe',
    'Wasp Sting'
}

modifiers.Properties = {
    --Archery
    ['Flaming Arrow'] = {'Flame', 'Light'},
    ['Piercing Arrow'] = {'Thunder', 'Light'},
    ['Dulling Arrow'] = {'Flame', 'Light'},
    ['Sidewinder'] = {'Aqua', 'Light'},
    ['Blast Arrow'] = {'Snow', 'Light'},
    ['Arching Arrow'] = {'Flame', 'Light'},
    ['Refulgent Arrow'] = {'Aqua', 'Light'},
    ['Empyreal Arrow'] = {'Flame', 'Light'},
    ['Namas Arrow'] = {'Flame', 'Light', 'Aqua', 'Snow'},
    ['Jishnu\'s Radiance'] = {'Flame', 'Light', 'Thunder', 'Breeze'},
    ['Apex Arrow'] = {'Thunder', 'Breeze', 'Light'},
    --Axe
    ['Raging Axe'] = {'Breeze', 'Thunder'},
    ['Smash Axe'] = {'Snow', 'Water'},
    ['Gale Axe'] = {'Breeze'},
    ['Avalanche Axe'] = {'Soil', 'Thunder'},
    ['Spinning Axe'] = {'Flame', 'Soil'},
    ['Rampage'] = {'Soil'},
    ['Calamity'] = {'Soil', 'Thunder'},
    ['Mistral Axe'] = {'Flame', 'Light'},
    ['Bora Axe'] = {'Soil', 'Breeze'},
    ['Decimation'] = {'Flame', 'Light'},
    ['Onslaught'] = {'Shadow', 'Soil', 'Snow', 'Aqua'},
    ['Primal Rend'] = {'Soil', 'Shadow', 'Aqua'},
    ['Cloudsplitter'] = {'Shadow', 'Soil', 'Snow', 'Aqua', 'Thunder', 'Breeze'},
    ['Ruinator'] = {'Snow', 'Aqua', 'Breeze'},
    --Club
    ['Shining Strike'] = {'Thunder'},
    ['Seraph Strike'] = {'Thunder'},
    ['Brainshaker'] = {'Aqua'},
    ['Starlight'] = {''},
    ['Moonlight'] = {''},
    ['Skullbreaker'] = {'Snow', 'Aqua'},
    ['True Strike'] = {'Breeze', 'Thunder'},
    ['Judgment'] = {'Thunder'},
    ['Hexa Strike'] = {'Flame', 'Light'},
    ['Flash Nova'] = {'Snow', 'Aqua'},
    ['Black Halo'] = {'Thunder', 'Breeze', 'Shadow'},
    ['Randgrith'] = {'Thunder', 'Flame', 'Breeze', 'Light'},
    ['Mystic Boon'] = {''},
    ['Dagan'] = {''},
    ['Reamrazer'] = {'Flame', 'Light', 'Thunder'},
    ['Exudiation'] = {'Shadow', 'Soil', 'Snow', 'Aqua', 'Thunder', 'Breeze'},
    --Dagger
    ['Wasp Sting'] = {'Soil'},
    ['Gust Slash'] = {'Breeze'},
    ['Shadow'] = {'Aqua'},
    ['Viper Bite'] = {'Soil'},
    ['Cyclone'] = {'Breeze', 'Thunder'},
    ['Energy Steal'] = {''},
    ['Energy Drain'] = {''},
    ['Dancing Edge'] = {'Soil', 'Breeze'},
    ['Shark Bite'] = {'Breeze', 'Thunder'},
    ['Aeolian Edge'] = {'Thunder', 'Soil', 'Breeze'},
    ['Evisceration'] = {'Soil', 'Shadow', 'Light'},
    ['Exenterator'] = {'Thunder', 'Breeze', 'Soil'},
    ['Mercy Stroke'] = {'Shadow', 'Soil', 'Snow', 'Aqua'},
    ['Mandalic Stab'] = {'Flame', 'Light', 'Shadow'},
    ['Pyrrhic Kleos'] = {'Snow', 'Aqua', 'Soil'},
    ['Mordant Rime'] = {'Thunder', 'Breeze', 'Snow', 'Aqua'},
    ['Rudra\'s Storm'] = {'Soil', 'Shadow', 'Snow', 'Aqua'},
    --Great Axe
    ['Shield Break'] = {'Thunder'},
    ['Iron Tempest'] = {'Soil'},
    ['Sturmwind'] = {'Aqua', 'Soil'},
    ['Armor Break'] = {'Thunder'},
    ['Keen Edge'] = {'Shadow'},
    ['Weapon Break'] = {'Aqua'},
    ['Raging Rush'] = {'Snow', 'Aqua'},
    ['Full Break'] = {'Snow', 'Aqua'},
    ['Fell Cleave'] = {'Thunder', 'Soil', 'Breeze'},
    ['Steel Cyclone'] = {'Snow', 'Aqua', 'Breeze'},
    ['Upheaval'] = {'Flame', 'Light', 'Shadow'},
    ['Metatron Torment'] = {'Flame', 'Light', 'Thunder', 'Breeze'},
    ['King\'s Justice'] = {'Thunder', 'Breeze', 'Soil'},
    ['Ukko\'s Fury'] = {'Flame', 'Light', 'Thunder', 'Breeze'},
    --Great Katana
    ['Tachi: Enpi'] = {'Light', 'Soil'},
    ['Tachi: Hobaku'] = {'Snow'},
    ['Tachi: Goten'] = {'Light', 'Thunder'},
    ['Tachi: Kagero'] = {'Flame'},
    ['Tachi: Jinpu'] = {'Soil', 'Breeze'},
    ['Tachi: Koki'] = {'Aqua', 'Thunder'},
    ['Tachi: Yukikaze'] = {'Snow', 'Breeze'},
    ['Tachi: Gekko'] = {'Snow', 'Aqua'},
    ['Tachi: Ageha'] = {'Shadow', 'Soil'},
    ['Tachi: Kasha'] = {'Flame', 'Light', 'Shadow'},
    ['Tachi: Shoha'] = {'Thunder', 'Breeze', 'Shadow'},
    ['Tachi: Kaiten'] = {'Flame', 'Light', 'Thunder', 'Breeze'},
    ['Tachi: Rana'] = {'Soil', 'Shadow', 'Snow'},
    ['Tachi: Fudo'] = {'Flame', 'Light', 'Thunder', 'Breeze', 'Snow', 'Aqua'},
    --Great Sword
    ['Hard Slash'] = {'Soil'},
    ['Power Slash'] = {'Light'},
    ['Frost Bite'] = {'Snow'},
    ['Freezebite'] = {'Snow', 'Breeze'},
    ['Shockwave'] = {'Aqua'},
    ['Crescent Moon'] = {'Soil'},
    ['Sickle Moon'] = {'Soil', 'THunder'},
    ['Spinning Slash'] = {'Thunder', 'Breeze'},
    ['Herculean Slash'] = {'Snow', 'Thunder', 'Breeze'},
    ['Ground Strike'] = {'Breeze', 'Thunder', 'Snow', 'Aqua'},
    ['Resolution'] = {'Thunder', 'Breeze', 'Soil'},
    ['Scourge'] = {'Flame', 'Light', 'Thunder', 'Breeze'},
    ['Torcleaver'] = {'Flame', 'Light', 'Thunder', 'Breeze', 'Snow', 'Aqua'},
    ['Dimidiation'] = {'Flame', 'Light', 'Thunder', 'Breeze'},
    --H2H
    ['Combo'] = {'Thunder'},
    ['Shoulder Tackle'] = {'Aqua', 'Thunder'},
    ['One Inch Punch'] = {'Shadow'},
    ['Backhand Blow'] = {'Breeze'},
    ['Raging Fists'] = {'Thunder'},
    ['Spinning Attack'] = {'Flame', 'Thunder'},
    ['Howling Fist'] = {'Light', 'Thunder'},
    ['Dragon Kick'] = {'Thunder', 'Breeze'},
    ['Tornado Kick'] = {'Snow', 'Thunder', 'Breeze'},
    ['Asuran Fists'] = {'Soil', 'Shadow', 'Flame'},
    ['Final Heaven'] = {'Flame', 'Light', 'Thunder', 'Breeze'},
    ['Ascetic\'s Fury'] = {'Flame', 'Light'},
    ['Stringing Pummel'] = {'Soil', 'Shadow', 'Flame'},
    ['Victory Smite'] = {'Flame', 'Light', 'Thunder', 'Breeze'},
    ['Shijin Spiral'] = {'Flame', 'Light', 'Aqua'},
    --Katana
    ['Blade: Rin'] = {'Light'},
    ['Blade: Retsu'] = {'Soil'},
    ['Blade: Teki'] = {'Aqua'},
    ['Blade: To'] = {'Snow', 'Breeze'},
    ['Blade: Chi'] = {'Thunder', 'Light'},
    ['Blade: Ei'] = {'Shadow'},
    ['Blade: Jin'] = {'Thunder', 'Breeze'},
    ['Blade: Ten'] = {'Shadow', 'Soil'},
    ['Blade: Yu'] = {'Aqua', 'Soil'},
    ['Blade: Ku'] = {'Shadow', 'Soil', 'Light'},
    ['Blade: Shun'] = {'Flame', 'Light', 'Thunder'},
    ['Blade: Metsu'] = {'Shadow', 'Soil', 'Snow', 'Aqua', 'Thunder', 'Breeze'},
    ['Blade: Kamu'] = {'Thunder', 'Breeze', 'Shadow'},
    ['Blade: Hi'] = {'Shadow', 'Soil', 'Snow', 'Aqua'},
    --Marksmanship
    ['Hot Shot'] = {'Flame', 'Light'},
    ['Split Shot'] = {'Aqua', 'Light'},
    ['Sniper Shot'] = {'Flame', 'Light'},
    ['Slug Shot'] = {'Aqua', 'Light', 'Breeze'},
    ['Blast Shot'] = {'Snow', 'Light'},
    ['Heavy Shot'] = {'Flame', 'Light'},
    ['Numbing Shot'] = {'Thunder', 'Breeze'},
    ['Detonator'] = {'Flame', 'Light'},
    ['Coronach'] = {'Shadow', 'Soil', 'Snow', 'Aqua', 'Thunder', 'Breeze'},
    ['Trueflight'] = {'Thunder', 'Breeze', 'Soil'},
    ['Leaden Salute'] = {'Shadow', 'Soil', 'Light'},
    ['Wildfire'] = {'Shadow', 'Soil', 'Snow', 'Aqua'},
    ['Last Stand'] = {'Flame', 'Light', 'Aqua'},
    --Polearm
    ['Double Thrust'] = {'Light'},
    ['Thunder Thrust'] = {'Light', 'Thunder'},
    ['Raiden Thrust'] = {'Light', 'Thunder'},
    ['Leg Sweep'] = {'Thunder'},
    ['Penta Thrust'] = {'Shadow'},
    ['Vorpal Thrust'] = {'Aqua', 'Light'},
    ['Skewer'] = {'Light', 'Thunder'},
    ['Wheeling Thrust'] = {'Flame', 'Light'},
    ['Sonic Thrust'] = {'Light', 'Soil'},
    ['Impulse Drive'] = {'Shadow', 'Soil', 'Snow'},
}

--Exported Function
modifiers.getMods = function(a)
    if(helpers.hasEntry(modifiers.STR, a)) then
        return 'STR';
    elseif(helpers.hasEntry(modifiers.VIT, a)) then
        return 'VIT';
    elseif(helpers.hasEntry(modifiers.DEX, a)) then
        return 'DEX';
    elseif(helpers.hasEntry(modifiers.AGI, a)) then
        return 'AGI';
    elseif(helpers.hasEntry(modifiers.INT, a)) then
        return 'INT';
    elseif(helpers.hasEntry(modifiers.MND, a)) then
        return 'MND';
    elseif(helpers.hasEntry(modifiers.CHR, a)) then
        return 'CHR';
    end
end

modifiers.getGorget = function(a, g)
    local prop = modifiers.Properties[a];
    for i = 1,#g do
        if(helpers.hasEntry(prop, g[i]))then
            return g[i];
        end
    end
    return 'Nil';
end

modifiers.QuickDraw = function(a)
    local QDTab = { 'Light Shot', 'Dark Shot', 'Fire Shot', 'Water Shot', 'Thunder Shot', 'Earth Shot', 'Wind Shot', 'Ice Shot'}
    if helpers.hasEntry(QDTab, a)then
        return 'Quick Draw';
    end
end

modifiers.wearObi = function(o, s)
    local env = gData.GetEnvironment();

    local stormTable = {
        ['Fire'] = 'Firestorm',
        ['Water'] = 'Rainstorm',
        ['Thunder'] = 'Thunderstorm',
        ['Earth'] = 'Sandstorm',
        ['Wind'] = 'Windstorm',
        ['Ice'] = 'Hailstorm',
        ['Light'] = 'Aurorastorm',
        ['Dark'] = 'Voidstorm'
    }


    local hasBuff = gData.GetBuffCount(stormTable[s.Element]) > 0;


    if ((s.Element == env.DayElement or s.Element == env.RawWeatherElement or hasBuff))then
        return o[s.Element];
    end
end

return modifiers;